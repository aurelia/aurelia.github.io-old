define(["npm:aurelia-bootstrapper@1.0.0-beta.1.2.0/aurelia-bootstrapper"], function(main) {
  return main;
});