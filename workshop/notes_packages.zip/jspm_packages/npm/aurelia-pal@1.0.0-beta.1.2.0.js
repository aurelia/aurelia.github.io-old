define(["npm:aurelia-pal@1.0.0-beta.1.2.0/aurelia-pal"], function(main) {
  return main;
});