define(["npm:aurelia-validation@0.6.6/index"], function(main) {
  return main;
});