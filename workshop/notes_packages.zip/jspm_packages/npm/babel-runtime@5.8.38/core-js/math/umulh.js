/* */ 
module.exports = { "default": require("core-js/library/fn/math/umulh"), __esModule: true };