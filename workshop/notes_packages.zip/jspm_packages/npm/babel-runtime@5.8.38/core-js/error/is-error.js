/* */ 
module.exports = { "default": require("core-js/library/fn/error/is-error"), __esModule: true };