define(["github:aurelia/task-queue@0.6.2/aurelia-task-queue"], function(main) {
  return main;
});