define(["github:aurelia/event-aggregator@0.7.0/aurelia-event-aggregator"], function(main) {
  return main;
});