define(["github:aurelia/path@0.8.1/aurelia-path"], function(main) {
  return main;
});