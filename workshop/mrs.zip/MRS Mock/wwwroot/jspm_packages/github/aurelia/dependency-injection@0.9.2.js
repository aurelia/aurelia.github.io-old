define(["github:aurelia/dependency-injection@0.9.2/aurelia-dependency-injection"], function(main) {
  return main;
});