/* */ 
"format cjs";
module.exports = require("./lib/polyfill");
