/* */ 
module.exports = { "default": require("core-js/library/fn/array/of"), __esModule: true };