/* */ 
require("../../modules/core.number.math");
module.exports = require("../../modules/$").core.Number.random;
