/* */ 
require("../../modules/es6.number.statics");
module.exports = Math.pow(2, -52);
