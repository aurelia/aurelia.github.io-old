/* */ 
require("../../modules/es6.number.statics");
module.exports = -0x1fffffffffffff;
