/* */ 
require("../../modules/js.array.statics");
module.exports = require("../../modules/$").core.Array.forEach;
