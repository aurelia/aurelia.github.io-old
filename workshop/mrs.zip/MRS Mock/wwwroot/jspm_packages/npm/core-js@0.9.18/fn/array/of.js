/* */ 
require("../../modules/es6.array.of");
module.exports = require("../../modules/$").core.Array.of;
