/* */ 
require("../../modules/es6.number.statics");
module.exports = parseInt;
