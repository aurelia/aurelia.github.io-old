import {autoinject} from 'aurelia-framework';
import {ProductsService, Product} from './products-service';

@autoinject
export class NewProductList {
  products:number[];
  
  constructor(private productsService:ProductsService){}

  bind(){
    this.productsService.getNewProducts().then(products => this.products = products);
  }
}
