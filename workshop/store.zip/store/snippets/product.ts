export class Product {
  productId:number;
  
  activate(params){
    this.productId = parseInt(params.id);
  }
}