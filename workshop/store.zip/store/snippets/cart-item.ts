import {bindable} from 'aurelia-framework';

export class CartItem {
  @bindable item = null;
}
