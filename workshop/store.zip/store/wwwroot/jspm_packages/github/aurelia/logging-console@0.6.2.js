define(["github:aurelia/logging-console@0.6.2/aurelia-logging-console"], function(main) {
  return main;
});