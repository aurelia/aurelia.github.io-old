define(["github:aurelia/metadata@0.7.3/aurelia-metadata"], function(main) {
  return main;
});