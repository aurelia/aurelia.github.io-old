define(["github:aurelia/templating-resources@0.14.0/aurelia-templating-resources"], function(main) {
  return main;
});