define(["github:aurelia/route-recognizer@0.6.2/aurelia-route-recognizer"], function(main) {
  return main;
});