define(["github:aurelia/logging@0.6.4/aurelia-logging"], function(main) {
  return main;
});