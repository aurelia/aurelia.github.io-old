/* */ 
require("../modules/es5");
module.exports = require("../modules/$").core;
