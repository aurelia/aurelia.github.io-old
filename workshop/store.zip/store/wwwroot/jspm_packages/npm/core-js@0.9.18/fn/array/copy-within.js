/* */ 
require("../../modules/es6.array.copy-within");
module.exports = require("../../modules/$").core.Array.copyWithin;
