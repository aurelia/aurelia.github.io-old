/* */ 
module.exports = { "default": require("core-js/library/fn/object/define"), __esModule: true };