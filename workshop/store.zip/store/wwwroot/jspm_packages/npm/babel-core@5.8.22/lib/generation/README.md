## Generation

Here is Babel's code generator, here you'll find all of the code to turn an AST
back into a string of code.

[TBD: To Be Documented:]

- Code Generator
- Buffer
- Source Maps
  - Position
- Printer
- Code Style
  - Whitespace
  - Parenthesis
- Generators
