﻿declare module "core-js" {
	export var core;
	export default core;
}