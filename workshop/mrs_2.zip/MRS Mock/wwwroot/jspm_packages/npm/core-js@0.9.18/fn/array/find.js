/* */ 
require("../../modules/es6.array.find");
module.exports = require("../../modules/$").core.Array.find;
