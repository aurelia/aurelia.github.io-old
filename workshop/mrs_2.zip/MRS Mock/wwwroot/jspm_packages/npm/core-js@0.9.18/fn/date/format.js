/* */ 
require("../../modules/core.date");
module.exports = require("../../modules/$").core.Date.format;
