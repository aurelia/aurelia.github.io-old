/* */ 
require("../modules/core.dict");
require("../modules/core.iter-helpers");
require("../modules/core.$for");
require("../modules/core.delay");
require("../modules/core.function.part");
require("../modules/core.object");
require("../modules/core.array.turn");
require("../modules/core.number.iterator");
require("../modules/core.number.math");
require("../modules/core.string.escape-html");
require("../modules/core.date");
require("../modules/core.global");
require("../modules/core.log");
module.exports = require("../modules/$").core;
