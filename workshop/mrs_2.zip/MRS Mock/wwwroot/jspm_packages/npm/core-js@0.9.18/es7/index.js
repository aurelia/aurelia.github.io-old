/* */ 
require("../modules/es7.array.includes");
require("../modules/es7.string.at");
require("../modules/es7.string.lpad");
require("../modules/es7.string.rpad");
require("../modules/es7.regexp.escape");
require("../modules/es7.object.get-own-property-descriptors");
require("../modules/es7.object.to-array");
require("../modules/es7.map.to-json");
require("../modules/es7.set.to-json");
module.exports = require("../modules/$").core;
