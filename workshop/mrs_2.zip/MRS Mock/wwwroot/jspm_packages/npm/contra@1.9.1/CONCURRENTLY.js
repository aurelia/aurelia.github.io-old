/* */ 
module.exports = Infinity;
