define(["github:aurelia/binding@0.8.6/aurelia-binding"], function(main) {
  return main;
});