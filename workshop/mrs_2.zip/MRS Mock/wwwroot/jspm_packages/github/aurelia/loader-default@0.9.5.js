define(["github:aurelia/loader-default@0.9.5/aurelia-loader-default"], function(main) {
  return main;
});