define(["github:aurelia/framework@0.15.0/aurelia-framework"], function(main) {
  return main;
});