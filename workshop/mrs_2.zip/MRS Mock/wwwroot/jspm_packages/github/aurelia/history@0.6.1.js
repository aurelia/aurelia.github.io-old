define(["github:aurelia/history@0.6.1/aurelia-history"], function(main) {
  return main;
});