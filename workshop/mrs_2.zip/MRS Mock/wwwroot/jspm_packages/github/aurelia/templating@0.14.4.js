define(["github:aurelia/templating@0.14.4/aurelia-templating"], function(main) {
  return main;
});