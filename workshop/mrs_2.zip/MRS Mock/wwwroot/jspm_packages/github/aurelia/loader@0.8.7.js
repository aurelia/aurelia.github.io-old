define(["github:aurelia/loader@0.8.7/aurelia-loader"], function(main) {
  return main;
});