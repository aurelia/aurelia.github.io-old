define(["github:aurelia/templating-binding@0.14.0/aurelia-templating-binding"], function(main) {
  return main;
});