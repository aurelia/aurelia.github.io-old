import 'bootstrap';
import {Aurelia} from 'aurelia-framework';

export function configure(aurelia:Aurelia) {
  aurelia.use
    .standardConfiguration()
    .developmentLogging()
    .feature('resources')
    .feature('promotions')
    .feature('products')
    .feature('pricing')
    .feature('cart')
    .feature('reviews')
    .feature('wish-list');

  aurelia.start().then(a => a.setRoot());
}
