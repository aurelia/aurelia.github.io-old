import {EventAggregator} from 'aurelia-event-aggregator';
import {autoinject} from 'aurelia-framework';
import {Router, RouterConfiguration} from 'aurelia-router';
import {CartUpdate} from 'cart/cart-update';

@autoinject
export class App {
  cartItemCount = 0;
  router:Router;
  
  constructor(eventAggregator:EventAggregator){
    eventAggregator.subscribe(CartUpdate, update => {
      this.cartItemCount = update.itemCount;
    });
  }
  
  configureRouter(config:RouterConfiguration, router:Router){
    config.title = 'Aurelia';
    config.map([
      { route: ['','home'],   name: 'home',       moduleId: './home',       title:'Home' },
      { route: 'search',      name: 'search',     moduleId: './search',     title:'Search' },
      { route: 'product/:id', name: 'product',    moduleId: './product',    title:'Product' },
      { route: 'cart',        name: 'cart',       moduleId: './cart',       title:'Cart' }
    ]);

    this.router = router;
  }

  search(query){
    this.router.navigateToRoute('search', {query:query});
  }
}
