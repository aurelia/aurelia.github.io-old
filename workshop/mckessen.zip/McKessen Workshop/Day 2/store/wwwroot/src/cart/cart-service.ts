import {ServiceDispatcher} from '../backend/service-dispatcher';
import {autoinject} from 'aurelia-framework';

export interface CartSummary {
  count:number;
}

export interface CartItem {
  productId:number;
  quantity:number;
}

export interface Cart {
  quantity:number;
  total:number;
  items:CartItem[];
}

@autoinject
export class CartService {
  constructor(private dispatcher:ServiceDispatcher){}

  addToCart(productId:number):Promise<CartSummary>{
    return this.dispatcher.enqueue<CartSummary>({
      type:'addToCart',
      productId:productId
    });
  }

  getCart():Promise<Cart>{
    return this.dispatcher.enqueue<Cart>({
      type:'getCart'
    });
  }
}
