import {bindable, autoinject} from 'aurelia-framework';
import {EventAggregator} from 'aurelia-event-aggregator';
import {CartService} from './cart-service';
import {CartUpdate} from './cart-update';

@autoinject
export class AddToCartButton {
  @bindable productId:number;

  constructor(private cartService:CartService, private eventAggregator:EventAggregator){}

  addToCart(){
    this.cartService.addToCart(this.productId).then(cart => {
      this.eventAggregator.publish(new CartUpdate(cart.count));
    });
  }
}
