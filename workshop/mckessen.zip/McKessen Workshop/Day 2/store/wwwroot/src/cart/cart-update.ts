export class CartUpdate{
  constructor(private itemCount:number){}
}