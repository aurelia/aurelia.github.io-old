import {ServiceDispatcher} from '../backend/service-dispatcher';
import {autoinject} from 'aurelia-framework';

export interface Product{
  id:number;
  name:string;
  description:string;
  imageUrl:string;
}

@autoinject
export class ProductsService {
  constructor(private dispatcher:ServiceDispatcher){}

  getNewProducts():Promise<number[]>{
    return this.dispatcher.enqueue<number[]>({
      type:'getNewProducts'
    });
  }

  getProduct(productId:number):Promise<Product>{
    return this.dispatcher.enqueue<Product>({
      type:'getProduct',
      productId:productId
    });
  }

  searchProducts(query):Promise<number[]>{
    return this.dispatcher.enqueue<number[]>({
      type:'searchProducts',
      query:query
    });
  }
}
