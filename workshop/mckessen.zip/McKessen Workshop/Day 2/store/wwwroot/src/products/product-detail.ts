import {bindable, autoinject} from 'aurelia-framework';
import {ProductsService, Product} from './products-service';

@autoinject
export class ProductDetail {
  @bindable productId:number;
  product:Product;

  constructor(private productsService:ProductsService){}

  productIdChanged(productId:number){
    if(productId){
      this.productsService.getProduct(productId).then(product => this.product = product);
    }
  }
}
