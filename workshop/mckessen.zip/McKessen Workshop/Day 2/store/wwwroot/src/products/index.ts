import {FrameworkConfiguration} from 'aurelia-framework';

export function configure(config:FrameworkConfiguration){
  config.globalResources([
    './new-product-list',
    './product-header',
    './product-summary',
    './product-detail'
  ]);
}
