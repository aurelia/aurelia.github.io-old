import {bindable} from 'aurelia-framework';

export class ProductSummary {
  @bindable productId:number;
}
