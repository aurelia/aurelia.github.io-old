import {CartService} from 'cart/cart-service';
import {autoinject} from 'aurelia-framework';

@autoinject
export class Cart {
  cart;
  
  constructor(private cartService:CartService){ }

  activate(){
    return this.cartService.getCart().then(cart => this.cart = cart);
  }
}
