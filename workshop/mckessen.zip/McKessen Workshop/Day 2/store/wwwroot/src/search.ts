import {autoinject} from 'aurelia-framework';
import {activationStrategy} from 'aurelia-router';
import {ProductsService} from 'products/products-service';

@autoinject
export class Search {
  query:string;
  products:Array<number>;
  
  constructor(private productsService:ProductsService){}

  determineActivationStrategy(){
    return activationStrategy.invokeLifecycle;
  }

  activate(params){
    this.query = params.query;
    return this.productsService.searchProducts(params.query).then(products => this.products = products);
  }
}
