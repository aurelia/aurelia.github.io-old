import {autoinject} from 'aurelia-framework';
import {PromotionService} from './promotion-service';

@autoinject
export class SaleList {
  products:number[];
  
  constructor(private saleService:PromotionService){}

  bind(){
    this.saleService.getSales().then(products => this.products = products);
  }
}
