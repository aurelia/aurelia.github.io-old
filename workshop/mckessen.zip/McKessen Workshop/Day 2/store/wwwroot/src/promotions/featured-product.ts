import {autoinject} from 'aurelia-framework';
import {PromotionService} from './promotion-service';

@autoinject
export class FeaturedProduct {
  productId:number;
  
  constructor(private saleService:PromotionService){}

  bind(){
    this.saleService.getFeature().then(productId => this.productId = productId);
  }
}
