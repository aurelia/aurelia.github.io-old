import {ServiceDispatcher} from '../backend/service-dispatcher';
import {autoinject} from 'aurelia-framework';

@autoinject
export class PromotionService {
  constructor(private dispatcher:ServiceDispatcher){}

  getSales():Promise<number[]>{
    return this.dispatcher.enqueue<number[]>({
      type:'getSales'
    });
  }

  getFeature():Promise<number>{
    return this.dispatcher.enqueue<number>({
      type:'getFeature'
    });
  }
}
