import {bindable, autoinject} from 'aurelia-framework';
import {ReviewsService} from './reviews-service';

@autoinject
export class ProductRating {
  @bindable productId:number;
  rating:number;

  constructor(private reviewsService:ReviewsService){}

  productIdChanged(productId:number){
    if(productId){
      this.reviewsService.getRating(productId).then(rating => this.rating = rating);
    }
  }
}
