import {bindable} from 'aurelia-framework';

export class ProductReview {
  @bindable review = null;
}
