import {ServiceDispatcher} from '../backend/service-dispatcher';
import {autoinject} from 'aurelia-framework';

export interface Review {
  rating:number;
  comment:string;
  contributor:string;
}

@autoinject
export class ReviewsService {
  constructor(private dispatcher:ServiceDispatcher){}

  getRating(productId:number):Promise<number>{
    return this.dispatcher.enqueue<number>({
      type:'getRating',
      productId:productId
    });
  }

  getReviews(productId:number):Promise<Review[]>{
    return this.dispatcher.enqueue<Review[]>({
      type:'getReviews',
      productId:productId
    });
  }
}
