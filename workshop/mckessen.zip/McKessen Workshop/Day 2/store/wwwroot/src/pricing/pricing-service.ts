import {ServiceDispatcher} from '../backend/service-dispatcher';
import {autoinject} from 'aurelia-framework';

@autoinject
export class PricingService {
  constructor(private dispatcher:ServiceDispatcher){}

  getPrice(productId):Promise<number>{
    return this.dispatcher.enqueue<number>({
      type:'getPrice',
      productId:productId
    });
  }
}
