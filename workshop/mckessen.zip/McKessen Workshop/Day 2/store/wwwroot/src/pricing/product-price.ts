import {bindable, autoinject} from 'aurelia-framework';
import {PricingService} from './pricing-service';

@autoinject
export class ProductPrice {
  @bindable productId:number;
  price:number;

  constructor(private pricingService:PricingService){}

  productIdChanged(productId:number){
    if(productId){
      this.pricingService.getPrice(productId).then(price => this.price = price);
    }
  }
}
