import {ReviewsService, Review} from 'reviews/reviews-service';
import {ProductsService} from 'products/products-service';
import {autoinject} from 'aurelia-framework';

@autoinject
export class Product {
  productId:number;
  reviews:Array<Review>;
  
  constructor(private productsService:ProductsService, private reviewsService:ReviewsService){}

  activate(params){
    this.productId = parseInt(params.id);
    this.reviewsService.getReviews(this.productId).then(reviews => this.reviews = reviews);
  }
}
