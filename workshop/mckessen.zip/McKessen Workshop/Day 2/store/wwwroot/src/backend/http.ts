const lorem = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.';
const imageUrl = 'images/camera.jpg';

function createReviews(){
  return [
    {rating:5, comment:lorem, contributor:'John Doe'},
    {rating:3, comment:lorem, contributor:'Jane Doe'},
    {rating:1, comment:lorem, contributor:'Jim Doe'},
  ];
}

const datastore = {
  featuredProduct:2,
  newProducts:[1,3,5],
  sales:[7,8,9],
  productsById:{
    [1]:{id:1, name:'Product 1', imageUrl:imageUrl, description:lorem},
    [2]:{id:2, name:'Product 2', imageUrl:imageUrl, description:lorem},
    [3]:{id:3, name:'Product 3', imageUrl:imageUrl, description:lorem},
    [4]:{id:4, name:'Product 4', imageUrl:imageUrl, description:lorem},
    [5]:{id:5, name:'Product 5', imageUrl:imageUrl, description:lorem},
    [6]:{id:6, name:'Product 6', imageUrl:imageUrl, description:lorem},
    [7]:{id:7, name:'Product 7', imageUrl:imageUrl, description:lorem},
    [8]:{id:8, name:'Product 8', imageUrl:imageUrl, description:lorem},
    [9]:{id:9, name:'Product 9', imageUrl:imageUrl, description:lorem},
    [10]:{id:10, name:'Product 10', imageUrl:imageUrl, description:lorem}
  },
  pricesById:{
    [1]:5,
    [2]:10,
    [3]:15,
    [4]:20,
    [5]:3,
    [6]:6,
    [7]:9,
    [8]:12,
    [9]:4,
    [10]:8
  },
  ratingsById:{
    [1]:5,
    [2]:3,
    [3]:4,
    [4]:1,
    [5]:5,
    [6]:5,
    [7]:4,
    [8]:4,
    [9]:4,
    [10]:2
  },
  reviewsById:{
    [1]:createReviews(),
    [2]:createReviews(),
    [3]:createReviews(),
    [4]:createReviews(),
    [5]:createReviews(),
    [6]:createReviews(),
    [7]:createReviews(),
    [8]:createReviews(),
    [9]:createReviews(),
    [10]:createReviews()
  },
  cart:{
    quantity:0,
    total:0,
    items:[]
  },
  wishList:[]
};

export class HttpClient {
  post(url, content):Promise<any[]>{
    return new Promise((resolve, reject) => {
      var results = [];
      console.log('processing batch', content.length);

      for(let message of content){
        results.push(this.handleMessage(message));
      }

      resolve(results);
    });
  }

  handleMessage(message){
    let result;

    switch(message.type){
      case 'addToCart':
        let existing = datastore.cart.items.filter(x => x.productId == message.productId)[0];
        if(existing){
          existing.quantity++;
        }else{
          datastore.cart.items.push({productId:message.productId, quantity: 1});
        }

        datastore.cart.total += datastore.pricesById[message.productId];
        datastore.cart.quantity++;

        result = { body: { count: datastore.cart.quantity } };
        break;
      case 'getCart':
        result = { body: JSON.parse(JSON.stringify(datastore.cart)) };
        break;
      case 'addToWishList':
        datastore.wishList.push({productId:message.productId, addedAt: Date.now()});
        result = { body: { count: datastore.wishList.length } };
        break;
      case 'getWishList':
        result = { body: JSON.parse(JSON.stringify(datastore.wishList)) };
        break;
      case 'getPrice':
        result = { body:datastore.pricesById[message.productId] };
        break;
      case 'getNewProducts':
        result = { body:JSON.parse(JSON.stringify(datastore.newProducts)) };
        break;
      case 'getSales':
        result = { body:JSON.parse(JSON.stringify(datastore.sales)) };
        break;
      case 'getFeature':
      result = { body:datastore.featuredProduct };
        break;
      case 'getProduct':
        result = { body:JSON.parse(JSON.stringify(datastore.productsById[message.productId])) };
        break;
      case 'searchProducts':
        let found = [];

        for(let id in datastore.productsById){
          let product = datastore.productsById[id];

          if(product.description.toLowerCase().indexOf(message.query.toLowerCase()) > -1){
            found.push(product.id);
          }
        }

        result = { body: found };
        break;
      case 'getRating':
        result = { body:datastore.ratingsById[message.productId] };
        break;
      case 'getReviews':
        result = { body:JSON.parse(JSON.stringify(datastore.reviewsById[message.productId])) };
        break;
      default:
        throw new Error('Unsupported message type: ' + message.type);
    }

    result.correlationId = message.correlationId;
    return result;
  }
}
