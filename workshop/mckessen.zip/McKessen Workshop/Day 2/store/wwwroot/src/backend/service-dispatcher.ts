import {HttpClient} from './http';
import {autoinject} from 'aurelia-framework';

@autoinject
export class ServiceDispatcher {
  queue = [];
  currentId = 0;
  throttle = 16;
  timeout;
  
  constructor(private http:HttpClient){ }

  nextId(){
    return ++this.currentId;
  }

  enqueue<T>(message):Promise<T>{
    if(this.timeout){
      clearTimeout(this.timeout);
      this.timeout = null;
    }

    return new Promise((resolve, reject) => {
      message.correlationId = this.nextId();

      this.queue.push({
        message:message,
        resolve:resolve,
        reject:reject
      });

      this.timeout = setTimeout(() => this.flush(), this.throttle);
    });
  }

  flush():void{
    let queue = this.queue;

    this.queue = [];
    this.timeout = null;

    this.http.post('api.mystore.com/messages', queue.map(x => x.message)).then(results => {
      results.forEach(result => {
        var found = queue.filter(x => x.message.correlationId === result.correlationId)[0];
        found.resolve(result.body);
      });
    });
  }
}
