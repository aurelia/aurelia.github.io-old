import {bindable} from 'aurelia-framework';

export class Stars {
  @bindable count = 0;
}
