export class CurrencyValueConverter {
  toView(value:number){
    if(value){
      return '$' + value.toFixed(2).replace(/(\d)(?=(\d{3})+\.)/g, '$1,');
    }
  }
}
