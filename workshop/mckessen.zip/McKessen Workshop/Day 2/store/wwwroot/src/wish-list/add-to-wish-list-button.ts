import {bindable, autoinject} from 'aurelia-framework';
import {WishListService} from './wish-list-service';

@autoinject
export class AddToWishListButton {
  @bindable productId:number;

  constructor(private wishListService:WishListService){}

  addToWishList(){
    this.wishListService.addToWishList(this.productId);
  }
}
