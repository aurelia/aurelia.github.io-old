import {ServiceDispatcher} from '../backend/service-dispatcher';
import {autoinject} from 'aurelia-framework';

export interface WishListSummary {
  count:number;
}

export interface WishListItem {
  productId:number;
  addedAt:Date;
}

@autoinject
export class WishListService {
  constructor(private dispatcher:ServiceDispatcher){}

  addToWishList(productId:number):Promise<WishListSummary>{
    return this.dispatcher.enqueue<WishListSummary>({
      type:'addToWishList',
      productId:productId
    });
  }
  
  getWishList():Promise<WishListItem[]>{
    return this.dispatcher.enqueue<WishListItem[]>({
      type:'getWishList'
    });
  }
}
