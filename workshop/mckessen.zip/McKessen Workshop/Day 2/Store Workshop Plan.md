# Store

## Intro
* main.ts
	* feature folders
* app.ts
* app.html

## Home Page
* Together: featured-product
	* Together: product-summary
	* Together: product-header
	* Together: product-rating
	* Student: product-price
* Together: new-product-list
* Student: sale-list

## Enhancements
* Together: stars
* Together: currency-value-converter

## Product Page
* Student: product-detail
* Together: add-to-cart-button
* Student: add-to-wish-list-button
* Student: product-review

## Enhancements
* Together: update cart count

## Search Page
* Together: query method on app
* Student: search.js (search.html provided)

## Cart
* Together: cart.html
* Together: cart-item
* Student: cart.js
* Student: display cart empty message

## Wish List
* Done entirely by student