export let studies = [
  {
    "Study": {
      "StudyID": 1,
      "StudyUID": "1.2.840.113674.1118.54.200",
      "AccessionNumber": "ACC001",
      "StudyDate": "2014-12-23T12:13:23",
      "DicomStudyID": "6",
      "Description": "",
      "NumSeries": 2,
      "NumImages": 18,
      "Patient": {
        "PatientID": 100001,
        "PatientContext": "MemorialHospital",
        "FullName": "BUXTON^STEVEN1",
        "BirthDate": "1967-03-25",
        "DicomPatientID": "GE1118",
        "Gender": "M"
      },
      "Modalities": [
        {
          "StudyModalityID": 2,
          "Modality": 2,
          "ModalityString": "MR",
          "ModalityDbValue": 2
        }
      ],
      "Series": [
        {
          "SeriesID": 2,
          "SeriesUID": "1.2.840.113674.1118.54.179.300",
          "Description": null,
          "FrameOfReferenceUID": "1.2.840.113619.2.1.1.2702874736.601.806637114.447",
          "FirstSlicePosition": "30.000000\\-125.000000\\125.000000",
          "FirstSliceOrientation": "0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000",
          "LastSlicePosition": "-30.000000\\-125.000000\\125.000000",
          "MinInstanceNumber": 1,
          "MaxInstanceNumber": 9,
          "ImageType": "ORIGINAL\\PRIMARY",
          "EchoTime": 76,
          "SeriesDate": "/Date(806680357000)/",
          "SeriesNumber": 102,
          "NumImages": 9,
          "BodyRegion": "neck",
          "Instances": [
            {
              "InstanceID": 17,
              "InstanceUID": "1.2.840.113674.950809132633027.100",
              "InstanceNumber": 1,
              "BlobUri": "images/img1.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 18,
              "InstanceUID": "images/img2.png",
              "InstanceNumber": 2,
              "BlobUri": "images/img3.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 19,
              "InstanceUID": "1.2.840.113674.950809132637053.100",
              "InstanceNumber": 3,
              "BlobUri": "images/img4.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 20,
              "InstanceUID": "1.2.840.113674.950809132638066.100",
              "InstanceNumber": 4,
              "BlobUri": "images/img5.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 21,
              "InstanceUID": "1.2.840.113674.950809132639083.100",
              "InstanceNumber": 5,
              "BlobUri": "images/img6.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 22,
              "InstanceUID": "1.2.840.113674.950809132641097.100",
              "InstanceNumber": 6,
              "BlobUri": "images/img7.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 23,
              "InstanceUID": "1.2.840.113674.950809132642110.100",
              "InstanceNumber": 7,
              "BlobUri": "images/img8.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 24,
              "InstanceUID": "1.2.840.113674.950809132644128.100",
              "InstanceNumber": 8,
              "BlobUri": "images/img9.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 25,
              "InstanceUID": "1.2.840.113674.950809132645138.100",
              "InstanceNumber": 9,
              "BlobUri": "images/img1.png",
              "NumberOfFrames": 1
            }
          ],
          "Modality": 2
        },
        {
          "SeriesID": 3,
          "SeriesUID": "1.2.840.113674.1118.54.180.300",
          "Description": null,
          "FrameOfReferenceUID": "1.2.840.113619.2.1.1.2702874736.601.806637114.447",
          "FirstSlicePosition": "-125.000000\\-125.000000\\-20.000000",
          "FirstSliceOrientation": "1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000",
          "LastSlicePosition": "-125.000000\\-125.000000\\40.000000",
          "MinInstanceNumber": 1,
          "MaxInstanceNumber": 9,
          "ImageType": "ORIGINAL\\PRIMARY",
          "EchoTime": 98,
          "SeriesDate": "/Date(806680357000)/",
          "SeriesNumber": 103,
          "NumImages": 9,
          "BodyRegion": "neck",
          "Instances": [
            {
              "InstanceID": 17,
              "InstanceUID": "1.2.840.113674.950809132633027.100",
              "InstanceNumber": 1,
              "BlobUri": "images/img2.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 18,
              "InstanceUID": "images/img2.png",
              "InstanceNumber": 2,
              "BlobUri": "images/img3.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 19,
              "InstanceUID": "1.2.840.113674.950809132637053.100",
              "InstanceNumber": 3,
              "BlobUri": "images/img4.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 20,
              "InstanceUID": "1.2.840.113674.950809132638066.100",
              "InstanceNumber": 4,
              "BlobUri": "images/img5.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 21,
              "InstanceUID": "1.2.840.113674.950809132639083.100",
              "InstanceNumber": 5,
              "BlobUri": "images/img6.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 22,
              "InstanceUID": "1.2.840.113674.950809132641097.100",
              "InstanceNumber": 6,
              "BlobUri": "images/img7.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 23,
              "InstanceUID": "1.2.840.113674.950809132642110.100",
              "InstanceNumber": 7,
              "BlobUri": "images/img8.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 24,
              "InstanceUID": "1.2.840.113674.950809132644128.100",
              "InstanceNumber": 8,
              "BlobUri": "images/img9.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 25,
              "InstanceUID": "1.2.840.113674.950809132645138.100",
              "InstanceNumber": 9,
              "BlobUri": "images/img1.png",
              "NumberOfFrames": 1
            }
          ],
          "Modality": 2
        }
      ]
    },
    "IsWebGLEnabled": false,
    "NumberOfMonitor": 1,
    "DisplayAreaArray": [
      {
        "Index": 0,
        "LayoutString": "TwoByTwo",
        "SeriesViewerArray": [
          {
            "RowIndex": 0,
            "ColumnIndex": 0,
            "LayoutString": null,
            "SeriesIndex": 0,
            "TopLeftImageIndex": 0,
            "Key": "0.0"
          },
          {
            "RowIndex": 0,
            "ColumnIndex": 1,
            "LayoutString": null,
            "SeriesIndex": 1,
            "TopLeftImageIndex": 0,
            "Key": "0.1"
          },
          {
            "RowIndex": 1,
            "ColumnIndex": 0,
            "LayoutString": null,
            "SeriesIndex": -1,
            "TopLeftImageIndex": 0,
            "Key": "1.0"
          },
          {
            "RowIndex": 1,
            "ColumnIndex": 1,
            "LayoutString": null,
            "SeriesIndex": -1,
            "TopLeftImageIndex": 0,
            "Key": "1.1"
          }
        ]
      }
    ]
  },
  {
    "Study": {
      "StudyID": 2,
      "StudyUID": "2.2.840.113674.1118.54.200",
      "AccessionNumber": "ACC002",
      "StudyDate": "2012-12-23T10:13:23",
      "DicomStudyID": "6",
      "Description": "",
      "NumSeries": 2,
      "NumImages": 18,
      "Patient": {
        "PatientID": 100002,
        "PatientContext": "MemorialHospital",
        "FullName": "BUXTON^STEVEN2",
        "BirthDate": "1980-05-14",
        "DicomPatientID": "GE1118",
        "Gender": "F"
      },
      "Modalities": [
        {
          "StudyModalityID": 2,
          "Modality": 2,
          "ModalityString": "MR",
          "ModalityDbValue": 2
        }
      ],
      "Series": [
        {
          "SeriesID": 2,
          "SeriesUID": "1.2.840.113674.1118.54.179.300",
          "Description": null,
          "FrameOfReferenceUID": "1.2.840.113619.2.1.1.2702874736.601.806637114.447",
          "FirstSlicePosition": "30.000000\\-125.000000\\125.000000",
          "FirstSliceOrientation": "0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000",
          "LastSlicePosition": "-30.000000\\-125.000000\\125.000000",
          "MinInstanceNumber": 1,
          "MaxInstanceNumber": 9,
          "ImageType": "ORIGINAL\\PRIMARY",
          "EchoTime": 76,
          "SeriesDate": "/Date(806680357000)/",
          "SeriesNumber": 102,
          "NumImages": 9,
          "BodyRegion": "right leg",
          "Instances": [
            {
              "InstanceID": 17,
              "InstanceUID": "1.2.840.113674.950809132633027.100",
              "InstanceNumber": 1,
              "BlobUri": "images/img3.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 18,
              "InstanceUID": "images/img2.png",
              "InstanceNumber": 2,
              "BlobUri": "images/img3.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 19,
              "InstanceUID": "1.2.840.113674.950809132637053.100",
              "InstanceNumber": 3,
              "BlobUri": "images/img4.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 20,
              "InstanceUID": "1.2.840.113674.950809132638066.100",
              "InstanceNumber": 4,
              "BlobUri": "images/img5.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 21,
              "InstanceUID": "1.2.840.113674.950809132639083.100",
              "InstanceNumber": 5,
              "BlobUri": "images/img6.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 22,
              "InstanceUID": "1.2.840.113674.950809132641097.100",
              "InstanceNumber": 6,
              "BlobUri": "images/img7.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 23,
              "InstanceUID": "1.2.840.113674.950809132642110.100",
              "InstanceNumber": 7,
              "BlobUri": "images/img8.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 24,
              "InstanceUID": "1.2.840.113674.950809132644128.100",
              "InstanceNumber": 8,
              "BlobUri": "images/img9.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 25,
              "InstanceUID": "1.2.840.113674.950809132645138.100",
              "InstanceNumber": 9,
              "BlobUri": "images/img1.png",
              "NumberOfFrames": 1
            }
          ],
          "Modality": 2
        },
        {
          "SeriesID": 3,
          "SeriesUID": "1.2.840.113674.1118.54.180.300",
          "Description": null,
          "FrameOfReferenceUID": "1.2.840.113619.2.1.1.2702874736.601.806637114.447",
          "FirstSlicePosition": "-125.000000\\-125.000000\\-20.000000",
          "FirstSliceOrientation": "1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000",
          "LastSlicePosition": "-125.000000\\-125.000000\\40.000000",
          "MinInstanceNumber": 1,
          "MaxInstanceNumber": 9,
          "ImageType": "ORIGINAL\\PRIMARY",
          "EchoTime": 98,
          "SeriesDate": "/Date(806680357000)/",
          "SeriesNumber": 103,
          "NumImages": 9,
          "BodyRegion": "right leg",
          "Instances": [
            {
              "InstanceID": 17,
              "InstanceUID": "1.2.840.113674.950809132633027.100",
              "InstanceNumber": 1,
              "BlobUri": "images/img4.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 18,
              "InstanceUID": "images/img2.png",
              "InstanceNumber": 2,
              "BlobUri": "images/img3.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 19,
              "InstanceUID": "1.2.840.113674.950809132637053.100",
              "InstanceNumber": 3,
              "BlobUri": "images/img4.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 20,
              "InstanceUID": "1.2.840.113674.950809132638066.100",
              "InstanceNumber": 4,
              "BlobUri": "images/img5.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 21,
              "InstanceUID": "1.2.840.113674.950809132639083.100",
              "InstanceNumber": 5,
              "BlobUri": "images/img6.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 22,
              "InstanceUID": "1.2.840.113674.950809132641097.100",
              "InstanceNumber": 6,
              "BlobUri": "images/img7.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 23,
              "InstanceUID": "1.2.840.113674.950809132642110.100",
              "InstanceNumber": 7,
              "BlobUri": "images/img8.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 24,
              "InstanceUID": "1.2.840.113674.950809132644128.100",
              "InstanceNumber": 8,
              "BlobUri": "images/img9.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 25,
              "InstanceUID": "1.2.840.113674.950809132645138.100",
              "InstanceNumber": 9,
              "BlobUri": "images/img1.png",
              "NumberOfFrames": 1
            }
          ],
          "Modality": 2
        }
      ]
    },
    "IsWebGLEnabled": false,
    "NumberOfMonitor": 1,
    "DisplayAreaArray": [
      {
        "Index": 0,
        "LayoutString": "TwoByTwo",
        "SeriesViewerArray": [
          {
            "RowIndex": 0,
            "ColumnIndex": 0,
            "LayoutString": null,
            "SeriesIndex": 0,
            "TopLeftImageIndex": 0,
            "Key": "0.0"
          },
          {
            "RowIndex": 0,
            "ColumnIndex": 1,
            "LayoutString": null,
            "SeriesIndex": 1,
            "TopLeftImageIndex": 0,
            "Key": "0.1"
          },
          {
            "RowIndex": 1,
            "ColumnIndex": 0,
            "LayoutString": null,
            "SeriesIndex": -1,
            "TopLeftImageIndex": 0,
            "Key": "1.0"
          },
          {
            "RowIndex": 1,
            "ColumnIndex": 1,
            "LayoutString": null,
            "SeriesIndex": -1,
            "TopLeftImageIndex": 0,
            "Key": "1.1"
          }
        ]
      }
    ]
  },
  {
    "Study": {
      "StudyID": 3,
      "StudyUID": "3.2.840.113674.1118.54.200",
      "AccessionNumber": "ACC003",
      "StudyDate": "2011-12-23T14:13:23",
      "DicomStudyID": "6",
      "Description": "",
      "NumSeries": 2,
      "NumImages": 18,
      "Patient": {
        "PatientID": 100003,        
        "PatientContext": "MemorialHospital",
        "FullName": "BUXTON^STEVEN3",
        "BirthDate": "1950-03-20",
        "DicomPatientID": "GE1118",
        "Gender": "M"
      },
      "Modalities": [
        {
          "StudyModalityID": 2,
          "Modality": 2,
          "ModalityString": "MR",
          "ModalityDbValue": 2
        }
      ],
      "Series": [
        {
          "SeriesID": 2,
          "SeriesUID": "1.2.840.113674.1118.54.179.300",
          "Description": null,
          "FrameOfReferenceUID": "1.2.840.113619.2.1.1.2702874736.601.806637114.447",
          "FirstSlicePosition": "30.000000\\-125.000000\\125.000000",
          "FirstSliceOrientation": "0.000000\\1.000000\\0.000000\\0.000000\\0.000000\\-1.000000",
          "LastSlicePosition": "-30.000000\\-125.000000\\125.000000",
          "MinInstanceNumber": 1,
          "MaxInstanceNumber": 9,
          "ImageType": "ORIGINAL\\PRIMARY",
          "EchoTime": 76,
          "SeriesDate": "/Date(806680357000)/",
          "SeriesNumber": 102,
          "NumImages": 9,
          "BodyRegion": "right foot",
          "Instances": [
            {
              "InstanceID": 17,
              "InstanceUID": "1.2.840.113674.950809132633027.100",
              "InstanceNumber": 1,
              "BlobUri": "images/img5.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 18,
              "InstanceUID": "images/img2.png",
              "InstanceNumber": 2,
              "BlobUri": "images/img3.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 19,
              "InstanceUID": "1.2.840.113674.950809132637053.100",
              "InstanceNumber": 3,
              "BlobUri": "images/img4.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 20,
              "InstanceUID": "1.2.840.113674.950809132638066.100",
              "InstanceNumber": 4,
              "BlobUri": "images/img5.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 21,
              "InstanceUID": "1.2.840.113674.950809132639083.100",
              "InstanceNumber": 5,
              "BlobUri": "images/img6.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 22,
              "InstanceUID": "1.2.840.113674.950809132641097.100",
              "InstanceNumber": 6,
              "BlobUri": "images/img7.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 23,
              "InstanceUID": "1.2.840.113674.950809132642110.100",
              "InstanceNumber": 7,
              "BlobUri": "images/img8.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 24,
              "InstanceUID": "1.2.840.113674.950809132644128.100",
              "InstanceNumber": 8,
              "BlobUri": "images/img9.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 25,
              "InstanceUID": "1.2.840.113674.950809132645138.100",
              "InstanceNumber": 9,
              "BlobUri": "images/img1.png",
              "NumberOfFrames": 1
            }
          ],
          "Modality": 2
        },
        {
          "SeriesID": 3,
          "SeriesUID": "1.2.840.113674.1118.54.180.300",
          "Description": null,
          "FrameOfReferenceUID": "1.2.840.113619.2.1.1.2702874736.601.806637114.447",
          "FirstSlicePosition": "-125.000000\\-125.000000\\-20.000000",
          "FirstSliceOrientation": "1.000000\\0.000000\\0.000000\\0.000000\\1.000000\\0.000000",
          "LastSlicePosition": "-125.000000\\-125.000000\\40.000000",
          "MinInstanceNumber": 1,
          "MaxInstanceNumber": 9,
          "ImageType": "ORIGINAL\\PRIMARY",
          "EchoTime": 98,
          "SeriesDate": "/Date(806680357000)/",
          "SeriesNumber": 103,
          "NumImages": 9,
          "BodyRegion": "right foot",
          "Instances": [
            {
              "InstanceID": 17,
              "InstanceUID": "1.2.840.113674.950809132633027.100",
              "InstanceNumber": 1,
              "BlobUri": "images/img6.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 18,
              "InstanceUID": "images/img2.png",
              "InstanceNumber": 2,
              "BlobUri": "images/img3.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 19,
              "InstanceUID": "1.2.840.113674.950809132637053.100",
              "InstanceNumber": 3,
              "BlobUri": "images/img4.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 20,
              "InstanceUID": "1.2.840.113674.950809132638066.100",
              "InstanceNumber": 4,
              "BlobUri": "images/img5.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 21,
              "InstanceUID": "1.2.840.113674.950809132639083.100",
              "InstanceNumber": 5,
              "BlobUri": "images/img6.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 22,
              "InstanceUID": "1.2.840.113674.950809132641097.100",
              "InstanceNumber": 6,
              "BlobUri": "images/img7.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 23,
              "InstanceUID": "1.2.840.113674.950809132642110.100",
              "InstanceNumber": 7,
              "BlobUri": "images/img8.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 24,
              "InstanceUID": "1.2.840.113674.950809132644128.100",
              "InstanceNumber": 8,
              "BlobUri": "images/img9.png",
              "NumberOfFrames": 1
            },
            {
              "InstanceID": 25,
              "InstanceUID": "1.2.840.113674.950809132645138.100",
              "InstanceNumber": 9,
              "BlobUri": "images/img1.png",
              "NumberOfFrames": 1
            }
          ],
          "Modality": 2
        }
      ]
    },
    "IsWebGLEnabled": false,
    "NumberOfMonitor": 1,
    "DisplayAreaArray": [
      {
        "Index": 0,
        "LayoutString": "TwoByTwo",
        "SeriesViewerArray": [
          {
            "RowIndex": 0,
            "ColumnIndex": 0,
            "LayoutString": null,
            "SeriesIndex": 0,
            "TopLeftImageIndex": 0,
            "Key": "0.0"
          },
          {
            "RowIndex": 0,
            "ColumnIndex": 1,
            "LayoutString": null,
            "SeriesIndex": 1,
            "TopLeftImageIndex": 0,
            "Key": "0.1"
          },
          {
            "RowIndex": 1,
            "ColumnIndex": 0,
            "LayoutString": null,
            "SeriesIndex": -1,
            "TopLeftImageIndex": 0,
            "Key": "1.0"
          },
          {
            "RowIndex": 1,
            "ColumnIndex": 1,
            "LayoutString": null,
            "SeriesIndex": -1,
            "TopLeftImageIndex": 0,
            "Key": "1.1"
          }
        ]
      }
    ]
  }
];
