import {studies} from './database';

export interface StudySummary {
    PatientID:string;
    StudyID:string;
    PatientName:string;
}

export interface Patient {
    PatientID: number;
    PatientContext: string;
    FullName: string;
    BirthDate: Date;
    DicomPatientID: string;
    Gender: string;
}

export interface Study {
    StudyID: number;
    AccessionNumber:string;
    Patient: Patient;
}

export interface RootStudy {
    Study:Study;
    DisplayAreaArray:Array<any>;
}

export class Server {
    getStudyList(): Promise<StudySummary[]>{
        let summaries = studies.map(x => { return {
            StudyID: x.Study.StudyID,
            PatientID: x.Study.Patient.PatientID,
            PatientName: x.Study.Patient.FullName
        }});
        
        return new Promise((resolve, reject) => resolve(summaries));
    }
    
    getRootStudy(studyid: number): Promise<RootStudy> {
        let found = studies.filter(x => x.Study.StudyID === studyid)[0];
        let clone = <RootStudy>JSON.parse(JSON.stringify(found));
        return new Promise((resolve, reject) => resolve(clone));
    }
}