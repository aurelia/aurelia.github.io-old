import {RouterConfiguration, Router} from 'aurelia-router';

export class App {
	configureRouter(config:RouterConfiguration, router:Router){
		config.title = 'MRS';
		config.map([
			{ route: ['', 'study-list'], moduleId:'./study-list' },
			{ route:'patient/:patientid/study/:studyid', moduleId:'./viewer' }
		]);
	}
}