import {autoinject} from 'aurelia-framework';
import {Router} from 'aurelia-router';
import {PatientContextManager} from 'viewer-context/patient-context-manager';

interface RouteParams {
	patientid;
	studyid:string;
}

@autoinject
export class Viewer {
	showSidebar: boolean = false;
	
	constructor(public patientContextManager:PatientContextManager, private router:Router) {}
	
	folderFinder(){
		console.log('folder finder');
	}
	
	studyList(){
		this.router.navigate('study-list');
	}
	
	appLauncher(){
		console.log('app launcher');
	}
	
	toggleSidebar() {
  	this.showSidebar = !this.showSidebar;
	}
	
	activate(params:RouteParams){
		return this.patientContextManager.openForAnchorStudy(parseInt(params.studyid));
	}
}