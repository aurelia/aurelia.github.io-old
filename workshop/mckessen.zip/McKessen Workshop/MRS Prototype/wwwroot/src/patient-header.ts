import {autoinject} from 'aurelia-framework';
import {PatientContextManager} from 'viewer-context/patient-context-manager';

@autoinject
export class PatientHeader {
	constructor(public patientContextManager:PatientContextManager){}
}