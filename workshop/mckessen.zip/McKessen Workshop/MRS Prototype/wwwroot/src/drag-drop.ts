﻿/// <reference path="../../typings/dragula.d.ts" />
import * as dragula from 'dragula';
import 'dragula/dist/dragula.css!'

export class DragAndDrop {
  dragging = false;

  startTracking() {
    let dragApi = dragula({
      isContainer: el => {
        if (!el) {
          return false;
        }

        if (dragApi.dragging) {
          return el.classList.contains('drop-target');
        }

        return el.classList.contains('drag-source');
      },
      revertOnSpill: true,
      delay: 200
    });

    this.trackDrop(dragApi);
    this.trackDraggingState(dragApi);
  }


  trackDrop(dragApi) {
    dragApi.on('drop', (el, container, source) => {
      dragApi.cancel();
      
      container.primaryBehavior.executionContext.recieveThumbnail(
        source.primaryBehavior.executionContext
      );
    });
  }

  trackDraggingState(dragApi) {
    let handle;
    
    dragApi.on('drag', () => {
      handle = setTimeout(() => this.dragging = true, 520);
    });
    
    dragApi.on('dragend', () => {
      clearTimeout(handle);
      this.dragging = false;
    });
  }
}
