import 'bootstrap';
import {Aurelia} from 'aurelia-framework';

export function configure(aurelia:Aurelia){
	aurelia.use
		.standardConfiguration()
		.developmentLogging()
		.feature('resources')
		.feature('thumbnails')
		.feature('display')
		.globalResources([
			'patient-header',
			'study-header',
			'sidebar'
		]);
		
	aurelia.start().then(x =>  x.setRoot());
}