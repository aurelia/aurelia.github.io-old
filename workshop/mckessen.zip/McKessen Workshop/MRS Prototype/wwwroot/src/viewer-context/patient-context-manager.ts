import {Server} from 'backend/server';
import {autoinject} from 'aurelia-framework';
import {PatientContext} from './patient-context';

@autoinject
export class PatientContextManager {
	openContexts:PatientContext[] = [];
	activeContext:PatientContext;
	
	constructor(private server:Server){ }
	
	getPatientContext(anchorStudyID): PatientContext{
		return this.openContexts.filter(x => x.id === anchorStudyID)[0];
	}
	
	activatePatientContext(patientContext:PatientContext){
		if(this.activeContext === patientContext){
			return;
		}
		
		if(this.activeContext){
			this.activeContext.deactivate();
		}
		
		this.activeContext = patientContext;
		
		if(this.openContexts.indexOf(patientContext) === -1){
			this.openContexts.push(patientContext);
		}
		
		if(this.activeContext){
			this.activeContext.activate();
		}
	}
	
	openForAnchorStudy(anchorStudyID:number): Promise<PatientContext> {
		let existing = this.getPatientContext(anchorStudyID);
		
		if(existing){
			this.activatePatientContext(existing);
			return Promise.resolve(existing);
		}
		
		return this.server.getRootStudy(anchorStudyID).then(rootStudy => {
			let context = new PatientContext(rootStudy);
			this.activatePatientContext(context);
			return context;
		});
	}
}