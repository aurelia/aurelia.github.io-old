import {Server, Patient, Study, RootStudy} from 'backend/server';

export class PatientContext {
	id:number;
	anchorStudy:Study;
	referenceStudies:Study[] = [];
	patient:Patient;
	presentation:Object;
	
	constructor(model:RootStudy) {
		this.id = model.Study.StudyID;
		this.anchorStudy = model.Study;
		this.patient = model.Study.Patient;
		this.presentation = model.DisplayAreaArray[0];
	}
	
	openReferenceStudy(study:Study){}
	
	activate(){}
	deactivate(){}
}