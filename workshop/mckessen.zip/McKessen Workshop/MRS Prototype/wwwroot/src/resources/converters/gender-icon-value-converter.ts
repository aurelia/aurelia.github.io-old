export class GendericonValueConverter{
	toView(genderString){
		if (genderString === 'M') return 'fa-male';
		else return 'fa-female';
	}
}