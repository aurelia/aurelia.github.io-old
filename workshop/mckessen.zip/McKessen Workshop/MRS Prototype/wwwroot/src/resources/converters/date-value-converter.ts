﻿export class DateValueConverter {
  toView(date): string {
    return new Date(date).toLocaleDateString();
  }
}