export class ExceptValueConverter {
	toView(all, exception){
		return all.filter(x => x !== exception);
	}
}