﻿export class TimeValueConverter {
    toView(date): string {
        return new Date(date).toLocaleTimeString();
    }
}