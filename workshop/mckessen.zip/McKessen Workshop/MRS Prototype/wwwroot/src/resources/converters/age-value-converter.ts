export class AgeValueConverter{
	toView(dob):string{
		let today = new Date().getFullYear();
		let dobYear = new Date(dob).getFullYear();
		
		let age = today - dobYear;
		return `${age.toString()}Y`;
	}	
}
