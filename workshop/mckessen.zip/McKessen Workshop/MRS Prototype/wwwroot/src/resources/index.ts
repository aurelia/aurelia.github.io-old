import {FrameworkConfiguration} from 'aurelia-framework';

export function configure(config:FrameworkConfiguration){
	config.globalResources([
		'./converters/except-value-converter',
		'./converters/age-value-converter',
		'./converters/date-value-converter',
		'./converters/time-value-converter',
		'./converters/gender-icon-value-converter',
		'./elements/toolbar',
		'./elements/tool',
		'./elements/menu',
		'./elements/menu-item'
	]);
}