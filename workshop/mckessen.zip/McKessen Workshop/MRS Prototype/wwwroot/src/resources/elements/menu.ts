﻿import {autoinject, noView, bindable} from 'aurelia-framework';
import {MenuItem} from './menu-item';

@autoinject
export class Menu {
    @bindable icon: string;
    @bindable name: string;
    @bindable launch: () => void;
    @bindable showSubMenu: boolean = false;

    @bindable menuItems: MenuItem[] = [];

    constructor() {
      //  this.menuItems.push(new MenuItem("Toolbars"));
      //  this.menuItems.push(new MenuItem("Appearence"));

       
    }

    bind() {
        if (this.name == "Workspace Settings") {
            this.showSubMenu = true;

        }
    }

    clickToExpand() {
        this.showSubMenu = !this.showSubMenu;
    }
}