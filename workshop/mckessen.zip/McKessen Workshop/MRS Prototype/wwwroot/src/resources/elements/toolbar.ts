import {Tool} from './tool';
import {sync} from 'aurelia-framework';

export class Toolbar {
	@sync('tool') tools:Tool[] = [];

	addTool(tool:Tool){
		this.tools.push(tool);
	}
	
	removeTool(tool:Tool){
		let index = this.tools.indexOf(tool);
		if(index !== -1){
			this.tools.splice(index, 1);
		}
	}
}