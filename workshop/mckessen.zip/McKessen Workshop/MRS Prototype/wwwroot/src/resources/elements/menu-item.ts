﻿import {bindable} from 'aurelia-framework';

export class MenuItem {
   @bindable Name: string;

    constructor(private name: string) {
        this.Name = name;
    }
}
