import {noView, bindable} from 'aurelia-framework';

@noView
export class Tool {
	@bindable icon: string;
	@bindable title: string;
	@bindable launch: () => void;
}