﻿import {Menu} from 'resources/elements/menu';
import {MenuItem} from 'resources/elements/menu-item';
import {bindable, autoinject} from 'aurelia-framework';

@autoinject
export class Sidebar {
    @bindable workspaceSettingMenu: MenuItem[] = [];
    @bindable preferenceMenu: MenuItem[] = [];

    constructor() {
        this.workspaceSettingMenu.push(new MenuItem("Toolbars"));
        this.workspaceSettingMenu.push(new MenuItem("Appearence"));

    }
}