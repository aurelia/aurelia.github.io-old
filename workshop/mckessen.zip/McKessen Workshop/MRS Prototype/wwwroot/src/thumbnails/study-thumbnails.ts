import {bindable} from 'aurelia-framework';
import {Study} from 'backend/server';

export class StudyThumbnails {
	@bindable study:Study;
	
	contextMenu(){
		console.log('menu');
	}
}