import {bindable} from 'aurelia-framework';

export class SeriesThumbnail {
	@bindable series;
}