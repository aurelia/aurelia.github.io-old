import {bindable} from 'aurelia-framework';

export class ThumbnailBar {
	@bindable patientContext;
	thumbnailsVisible:boolean = true;
	
	toggle(){
		this.thumbnailsVisible = !this.thumbnailsVisible;
	}
}