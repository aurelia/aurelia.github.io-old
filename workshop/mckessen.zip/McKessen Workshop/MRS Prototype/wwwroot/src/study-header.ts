import {bindable} from 'aurelia-framework';

export class StudyHeader {
    @bindable patientContext;

    
    changeDisplayProtocolHandler() {    
        alert("changeDisplayProtocol here!");
    }

    markStudyAsReportedHandler() {
        alert("mark Study As Reported here!");
    }
}