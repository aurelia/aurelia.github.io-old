import {Server, StudySummary} from 'backend/server';
import {autoinject} from 'aurelia-framework';

@autoinject
export class Home {
	studyList:StudySummary[];
	
	constructor(private server:Server) {}
	
	activate(){
		return this.server.getStudyList().then(x => this.studyList = x);
	}
}