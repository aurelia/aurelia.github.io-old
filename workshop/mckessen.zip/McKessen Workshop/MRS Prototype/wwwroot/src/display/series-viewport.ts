import {bindable} from 'aurelia-framework';

export class SeriesViewport {
	@bindable configuration;
	@bindable context;
	series;
	surface:HTMLCanvasElement;
	drawingContext:CanvasRenderingContext2D;
	
	imageSrc:string;
	
	attached(){
		this.drawingContext = this.surface.getContext('2d');
		this.render();
	}
	
	recieveThumbnail(seriesThumbnail){
		this.series = seriesThumbnail.series;
		this.render();
	}
	
	render(){
		if(this.series){
			//get images
			//manipulate images
			//use context to draw image
		}
	}
	
	bind(){
		this.series = this.context.anchorStudy.Series[0];
	}
	
	configurationChanged(value){
		this.bind();
		this.render();
	}
	
	contextChanged(value){
		this.bind();
		this.render();
	}
}