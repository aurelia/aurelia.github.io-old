import {autoinject, TaskQueue} from 'aurelia-framework';

@autoinject
export class LayoutCustomAttribute {
  value:any;
  onLayoutRequested:EventListener;
  
	constructor(private element:Element, private taskQueue:TaskQueue) {
    this.onLayoutRequested = () => this.doLayout();
  }
  
  bind(){
    this.taskQueue.queueMicroTask(() => {
      this.doLayout();
      window.addEventListener('resize', this.onLayoutRequested);
    });
  }
  
  unbind(){
    window.removeEventListener('resize', this.onLayoutRequested);
  }
  
	valueChanged(newValue, oldValue){
    this.doLayout();
	}
  
  doLayout(){
    let children = <HTMLElement[]>Array.prototype.slice.call((<HTMLElement>this.element).children);
		arrange(this.value.presentation.LayoutString, <HTMLElement>this.element, children)
  }
}

function arrange(layoutType: string, parent: HTMLElement, children: HTMLElement[]) {
     //TODO parse layoutType to row/col
		 
    let row = 2;
    let col = 2;
    let left = parent.clientLeft, top = parent.clientTop;
    let viewportHeight = parent.clientHeight / row;
    let viewportWidth = parent.clientWidth / col;

    for (let i = 0; i < row; i++) {
        for (let j = 0; j < col; j++) {
            // set the child coordinates here
            let child = children[i * row + j];
            child.style.left = left + 'px';
            child.style.width = viewportWidth + 'px';
            child.style.top = top + 'px';
            child.style.height = viewportHeight + 'px';
            child.style.position = 'absolute';

            left += viewportWidth;
        }
				
        top += viewportHeight;
        left = parent.clientLeft;
    }
}