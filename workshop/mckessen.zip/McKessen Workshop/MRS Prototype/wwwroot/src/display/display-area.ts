import {bindable, autoinject} from 'aurelia-framework';
import {DragAndDrop} from 'drag-drop';

@autoinject
export class DisplayArea {
	@bindable patientContext;
	dragAndDrop: DragAndDrop;
	
	constructor(dragDrop: DragAndDrop) {
    this.dragAndDrop = dragDrop;
	}
	
	attached() {
		this.dragAndDrop.startTracking();
 	}
}