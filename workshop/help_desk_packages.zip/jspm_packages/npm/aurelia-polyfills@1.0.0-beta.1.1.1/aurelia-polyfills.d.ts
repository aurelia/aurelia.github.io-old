declare module 'aurelia-polyfills' {
  import {
    PLATFORM
  } from 'aurelia-pal';
}