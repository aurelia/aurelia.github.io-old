define(["npm:aurelia-dialog@0.5.10/aurelia-dialog"], function(main) {
  return main;
});