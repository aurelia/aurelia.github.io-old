/* */ 
module.exports = { "default": require("core-js/library/fn/string/trim-left"), __esModule: true };