/* */ 
module.exports = { "default": require("core-js/library/fn/system/global"), __esModule: true };