/* */ 
module.exports = require('./objectDestructuringEmpty');
