define(["npm:aurelia-path@1.0.0-beta.1.2.0/aurelia-path"], function(main) {
  return main;
});