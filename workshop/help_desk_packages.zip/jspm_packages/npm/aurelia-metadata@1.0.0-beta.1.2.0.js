define(["npm:aurelia-metadata@1.0.0-beta.1.2.0/aurelia-metadata"], function(main) {
  return main;
});