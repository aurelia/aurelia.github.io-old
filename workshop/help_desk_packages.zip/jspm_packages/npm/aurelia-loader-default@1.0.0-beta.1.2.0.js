define(["npm:aurelia-loader-default@1.0.0-beta.1.2.0/aurelia-loader-default"], function(main) {
  return main;
});