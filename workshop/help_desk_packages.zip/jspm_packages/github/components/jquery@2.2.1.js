define(["github:components/jquery@2.2.1/jquery"], function(main) {
  return main;
});