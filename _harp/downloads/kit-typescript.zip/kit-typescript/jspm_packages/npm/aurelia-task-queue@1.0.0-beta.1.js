define(["npm:aurelia-task-queue@1.0.0-beta.1/aurelia-task-queue"], function(main) {
  return main;
});