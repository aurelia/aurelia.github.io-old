define(["npm:aurelia-history-browser@1.0.0-beta.1/aurelia-history-browser"], function(main) {
  return main;
});