/* */ 
require('../../modules/es6.string.code-point-at');
module.exports = require('../../modules/$.core').String.codePointAt;
