/* */ 
require('../../modules/es6.math.log1p');
module.exports = require('../../modules/$.core').Math.log1p;
