/* */ 
require('../modules/web.timers');
module.exports = require('../modules/$.core').setInterval;
