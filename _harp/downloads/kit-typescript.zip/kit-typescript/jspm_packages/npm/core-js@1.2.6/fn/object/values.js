/* */ 
require('../../modules/es7.object.values');
module.exports = require('../../modules/$.core').Object.values;
