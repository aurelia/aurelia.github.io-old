/* */ 
require('../../modules/es6.object.is-sealed');
module.exports = require('../../modules/$.core').Object.isSealed;
