/* */ 
module.exports = require('./string/index');
