/* */ 
var $ = require('../../modules/$');
module.exports = function defineProperty(it, key, desc) {
  return $.setDesc(it, key, desc);
};
