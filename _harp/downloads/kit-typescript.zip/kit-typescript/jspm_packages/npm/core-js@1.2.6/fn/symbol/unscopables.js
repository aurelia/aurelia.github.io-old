/* */ 
module.exports = require('../../modules/$.wks')('unscopables');
