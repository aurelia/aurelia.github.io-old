define(["npm:aurelia-framework@1.0.0-beta.1.0.1/aurelia-framework"], function(main) {
  return main;
});