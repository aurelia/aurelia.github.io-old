define(["github:aurelia/logging-console@0.8.0/aurelia-logging-console"], function(main) {
  return main;
});