define(["github:aurelia/pal@0.2.0/aurelia-pal"], function(main) {
  return main;
});