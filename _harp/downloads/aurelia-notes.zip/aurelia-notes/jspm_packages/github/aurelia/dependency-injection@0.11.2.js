define(["github:aurelia/dependency-injection@0.11.2/aurelia-dependency-injection"], function(main) {
  return main;
});