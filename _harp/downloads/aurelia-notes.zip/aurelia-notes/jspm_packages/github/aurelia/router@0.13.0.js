define(["github:aurelia/router@0.13.0/aurelia-router"], function(main) {
  return main;
});