define(["github:aurelia/templating@0.16.0/aurelia-templating"], function(main) {
  return main;
});