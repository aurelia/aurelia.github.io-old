define(["github:aurelia/templating-binding@0.16.1/aurelia-templating-binding"], function(main) {
  return main;
});