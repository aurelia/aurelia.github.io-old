define(["github:aurelia/templating-resources@0.16.1/aurelia-templating-resources"], function(main) {
  return main;
});