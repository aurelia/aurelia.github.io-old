define(["github:aurelia/binding@0.10.1/aurelia-binding"], function(main) {
  return main;
});