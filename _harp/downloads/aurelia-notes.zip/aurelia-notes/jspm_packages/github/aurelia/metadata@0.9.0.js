define(["github:aurelia/metadata@0.9.0/aurelia-metadata"], function(main) {
  return main;
});