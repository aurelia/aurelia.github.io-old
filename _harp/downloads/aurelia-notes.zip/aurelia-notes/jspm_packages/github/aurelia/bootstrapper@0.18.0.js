define(["github:aurelia/bootstrapper@0.18.0/aurelia-bootstrapper"], function(main) {
  return main;
});