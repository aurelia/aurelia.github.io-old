define(["github:aurelia/loader-default@0.11.2/aurelia-loader-default"], function(main) {
  return main;
});