define(["github:aurelia/logging@0.8.0/aurelia-logging"], function(main) {
  return main;
});