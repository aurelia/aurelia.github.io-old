define(["github:aurelia/dialog@0.4.1/index"], function(main) {
  return main;
});