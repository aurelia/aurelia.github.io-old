define(["github:aurelia/pal-browser@0.2.0/aurelia-pal-browser"], function(main) {
  return main;
});