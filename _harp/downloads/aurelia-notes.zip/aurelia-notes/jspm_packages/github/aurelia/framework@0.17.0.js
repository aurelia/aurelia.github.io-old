define(["github:aurelia/framework@0.17.0/aurelia-framework"], function(main) {
  return main;
});