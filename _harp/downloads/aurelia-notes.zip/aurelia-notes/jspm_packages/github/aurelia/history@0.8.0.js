define(["github:aurelia/history@0.8.0/aurelia-history"], function(main) {
  return main;
});