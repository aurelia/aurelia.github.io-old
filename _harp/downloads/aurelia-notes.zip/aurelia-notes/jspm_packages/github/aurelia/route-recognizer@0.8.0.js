define(["github:aurelia/route-recognizer@0.8.0/aurelia-route-recognizer"], function(main) {
  return main;
});