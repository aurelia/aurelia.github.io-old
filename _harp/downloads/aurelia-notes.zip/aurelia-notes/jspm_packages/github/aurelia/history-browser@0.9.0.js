define(["github:aurelia/history-browser@0.9.0/aurelia-history-browser"], function(main) {
  return main;
});