define(["github:aurelia/animator-css@0.17.0/aurelia-animator-css"], function(main) {
  return main;
});