define(["github:aurelia/path@0.10.0/aurelia-path"], function(main) {
  return main;
});