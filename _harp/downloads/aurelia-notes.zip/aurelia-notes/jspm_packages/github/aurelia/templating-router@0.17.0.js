define(["github:aurelia/templating-router@0.17.0/aurelia-templating-router"], function(main) {
  return main;
});