define(["github:aurelia/loader@0.10.0/aurelia-loader"], function(main) {
  return main;
});