define(["github:aurelia/task-queue@0.8.0/aurelia-task-queue"], function(main) {
  return main;
});