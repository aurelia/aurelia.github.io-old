define(["github:components/jquery@2.1.4/jquery"], function(main) {
  return main;
});