define(["npm:aurelia-logging@1.0.0-beta.1.1.1/aurelia-logging"], function(main) {
  return main;
});