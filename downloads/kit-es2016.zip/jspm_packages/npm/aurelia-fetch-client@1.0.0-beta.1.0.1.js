define(["npm:aurelia-fetch-client@1.0.0-beta.1.0.1/aurelia-fetch-client"], function(main) {
  return main;
});