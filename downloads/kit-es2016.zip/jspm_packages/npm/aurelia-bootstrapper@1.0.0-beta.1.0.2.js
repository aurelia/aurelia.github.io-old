define(["npm:aurelia-bootstrapper@1.0.0-beta.1.0.2/aurelia-bootstrapper"], function(main) {
  return main;
});