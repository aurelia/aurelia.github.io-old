/* */ 
module.exports = { "default": require("core-js/library/fn/array/sort"), __esModule: true };