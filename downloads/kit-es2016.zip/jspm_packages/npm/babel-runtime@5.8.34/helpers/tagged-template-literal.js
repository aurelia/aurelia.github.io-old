/* */ 
"use strict";
var _Object$freeze = require("../core-js/object/freeze")["default"];
var _Object$defineProperties = require("../core-js/object/define-properties")["default"];
exports["default"] = function(strings, raw) {
  return _Object$freeze(_Object$defineProperties(strings, {raw: {value: _Object$freeze(raw)}}));
};
exports.__esModule = true;
