define(["npm:aurelia-templating-resources@1.0.0-beta.1.0.3/aurelia-templating-resources"], function(main) {
  return main;
});