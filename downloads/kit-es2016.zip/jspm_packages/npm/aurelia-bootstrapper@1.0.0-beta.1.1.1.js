define(["npm:aurelia-bootstrapper@1.0.0-beta.1.1.1/aurelia-bootstrapper"], function(main) {
  return main;
});