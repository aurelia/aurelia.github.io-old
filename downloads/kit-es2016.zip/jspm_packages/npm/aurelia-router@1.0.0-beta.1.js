define(["npm:aurelia-router@1.0.0-beta.1/aurelia-router"], function(main) {
  return main;
});