/* */ 
require("../modules/es6.symbol");
require("../modules/es6.object.to-string");
module.exports = require("../modules/$.core").Symbol;
