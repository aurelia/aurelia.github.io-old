/* */ 
require('../../../modules/es6.array.copy-within');
module.exports = require('../../../modules/_entry-virtual')('Array').copyWithin;
