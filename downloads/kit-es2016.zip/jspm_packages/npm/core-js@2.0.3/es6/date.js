/* */ 
require('../modules/es6.date.to-string');
module.exports = Date;
