define(["npm:aurelia-binding@1.0.0-beta.1.0.1/aurelia-binding"], function(main) {
  return main;
});