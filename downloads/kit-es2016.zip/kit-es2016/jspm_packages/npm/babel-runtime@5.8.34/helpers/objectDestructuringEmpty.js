/* */ 
"use strict";

exports.default = function (obj) {
  if (obj == null) throw new TypeError("Cannot destructure undefined");
};

exports.__esModule = true;