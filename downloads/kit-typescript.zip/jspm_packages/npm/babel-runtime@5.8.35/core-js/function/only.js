/* */ 
module.exports = { "default": require("core-js/library/fn/function/only"), __esModule: true };