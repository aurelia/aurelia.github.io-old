/* */ 
module.exports = require('./taggedTemplateLiteral');
