/* */ 
module.exports = require('./taggedTemplateLiteralLoose');
