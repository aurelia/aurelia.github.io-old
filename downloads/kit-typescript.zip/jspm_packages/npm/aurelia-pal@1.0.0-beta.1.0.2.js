define(["npm:aurelia-pal@1.0.0-beta.1.0.2/aurelia-pal"], function(main) {
  return main;
});