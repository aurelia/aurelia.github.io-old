define(["npm:aurelia-loader-default@1.0.0-beta.1.0.2/aurelia-loader-default"], function(main) {
  return main;
});