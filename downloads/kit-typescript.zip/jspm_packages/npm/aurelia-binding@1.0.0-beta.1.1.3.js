define(["npm:aurelia-binding@1.0.0-beta.1.1.3/aurelia-binding"], function(main) {
  return main;
});