/* */ 
module.exports = require('./es6/index');
