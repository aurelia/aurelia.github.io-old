define(["npm:aurelia-history@1.0.0-beta.1.1.1/aurelia-history"], function(main) {
  return main;
});