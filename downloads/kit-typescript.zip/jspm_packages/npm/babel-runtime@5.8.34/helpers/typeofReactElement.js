/* */ 
"use strict";
var _for = require('../core-js/symbol/for');
var _for2 = _interopRequireDefault(_for);
var _symbol = require('../core-js/symbol');
var _symbol2 = _interopRequireDefault(_symbol);
function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {default: obj};
}
exports.default = typeof _symbol2.default === "function" && _for2.default && (0, _for2.default)("react.element") || 0xeac7;
exports.__esModule = true;
