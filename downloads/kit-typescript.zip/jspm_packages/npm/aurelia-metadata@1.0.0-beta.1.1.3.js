define(["npm:aurelia-metadata@1.0.0-beta.1.1.3/aurelia-metadata"], function(main) {
  return main;
});