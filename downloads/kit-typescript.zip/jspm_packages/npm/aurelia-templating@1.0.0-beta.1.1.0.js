define(["npm:aurelia-templating@1.0.0-beta.1.1.0/aurelia-templating"], function(main) {
  return main;
});