define(["npm:aurelia-templating@1.0.0-beta.1.0.2/aurelia-templating"], function(main) {
  return main;
});