define(["npm:aurelia-metadata@1.0.0-beta.1.1.4/aurelia-metadata"], function(main) {
  return main;
});