define(["npm:aurelia-templating-router@1.0.0-beta.1.1.1/aurelia-templating-router"], function(main) {
  return main;
});