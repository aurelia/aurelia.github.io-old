define(["npm:aurelia-binding@1.0.0-beta.1.1.0/aurelia-binding"], function(main) {
  return main;
});